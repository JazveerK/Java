//Android TicTacToe
//Jazveer Kaler
//March 2nd 2023

package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //create all variables
    Button[][] matrix = new Button[3][3];
    int[][] platform = new int[3][3];
    final int BLANK = 0;
    final int X_MOVE = 1;
    final int O_MOVE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        matrix[0][0] = (Button) this.findViewById(R.id.button1);
        matrix[0][1] = (Button) this.findViewById(R.id.button2);
        matrix[0][2] = (Button) this.findViewById(R.id.button3);
        matrix[1][0] = (Button) this.findViewById(R.id.button4);
        matrix[1][1] = (Button) this.findViewById(R.id.button5);
        matrix[1][2] = (Button) this.findViewById(R.id.button6);
        matrix[2][0] = (Button) this.findViewById(R.id.button7);
        matrix[2][1] = (Button) this.findViewById(R.id.button8);
        matrix[2][2] = (Button) this.findViewById(R.id.button9);
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < 3; y++) {
                matrix[x][y].setOnClickListener(this);
            }
        }
    }

    @Override
    //creates the buttons and moves
    public void onClick(View v) {
        Button b = (Button) v;
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < 3; y++) {
                if (b.equals(matrix[x][y])) {
                    if (platform[x][y] == BLANK) {
                        b.setText("X");
                        b.setEnabled(false);
                        platform[x][y] = X_MOVE;
                        if (checkWin(X_MOVE) == true) {
                            Toast.makeText(this, "X wins!", Toast.LENGTH_SHORT).show();
                            clearPlatform();
                            return;
                        }
                        if (checkTie() == true) {
                            Toast.makeText(this, "Tie!", Toast.LENGTH_SHORT).show();
                            clearPlatform();
                            return;
                        }
                        //check win
                        aiMove();
                        if (checkWin(O_MOVE) == true) {
                            Toast.makeText(this, "O Wins!", Toast.LENGTH_SHORT).show();
                            clearPlatform();
                            return;
                        }
                        if (checkTie() == true) {
                            clearPlatform();
                            return;
                        }
                    }
                }
            }
        }
    }
    public void aiMove() {
        //try to win
        if (checkSingleBlank(O_MOVE)) {
            return;
        }
        //try to block
        if (checkSingleBlank(X_MOVE)) {
            return;
        }
        //play randomly
        ArrayList<Integer> list = new ArrayList<Integer>();
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < 3; y++) {
                if (platform[x][y] == BLANK) {
                    list.add(x*10+y);
                }
            }
        }
        int choice = (int)(Math.random() * list.size());
        platform[list.get(choice) / 10][list.get(choice) % 10] = O_MOVE;
        matrix[list.get(choice) / 10][list.get(choice) % 10].setText("O");
        matrix[list.get(choice) / 10][list.get(choice) % 10].setEnabled(false);
        Toast.makeText(this, "Played Randomly", Toast.LENGTH_SHORT).show();
    }

    public boolean checkSingleBlank(int player) {

        int oCount = 0;
        int blankCount = 0;
        int blankX = 0;
        int blankY = 0;
        //check column win
        for (int x = 0; x<3; x++) {
            oCount = 0;
            blankCount = 0;
            blankX = 0;
            blankY = 0;
            for (int y = 0; y<3; y++) {
                if (platform[x][y] == BLANK) {
                    blankCount++;
                    blankX = x;
                    blankY = y;
                }
                if (platform[x][y] == player) {
                    oCount++;
                }
            }
            if (oCount == 2 && blankCount == 1) {
                platform[blankX][blankY] = O_MOVE;
                matrix[blankX][blankY].setText("O");
                matrix[blankX][blankY].setEnabled(false);
                return true;
            }
        }
        //check row wins
        for (int y = 0; y < 3; y++) {
            oCount = 0;
            blankCount = 0;
            blankX = 0;
            blankY = 0;
            for (int x = 0; x < 3; x++) {
                if (platform[x][y] == BLANK) {
                    blankCount++;
                    blankX = x;
                    blankY = y;
                }
                if (platform[x][y] == player) {
                    oCount++;
                }
            }
            if (oCount == 2 && blankCount == 1) {
                platform[blankX][blankY] = O_MOVE;
                matrix[blankX][blankY].setText("O");
                matrix[blankX][blankY].setEnabled(false);
                return true;
            }
        }
        //check top left to bottom right diagonal
        oCount = 0;
        blankCount = 0;
        blankX = 0;
        blankY = 0;
        if (platform[0][0] == BLANK) {
            blankCount++;
            blankX = 0;
            blankY = 0;
        }
        if (platform[0][0] == player) {
            oCount++;
        }
        if (platform[1][1] == BLANK) {
            blankCount++;
            blankX = 1;
            blankY = 1;
        }
        if (platform[1][1] == player) {
            oCount++;
        }
        if (platform[2][2] == BLANK) {
            blankCount++;
            blankX = 2;
            blankY = 2;
        }
        if (platform[2][2] == player) {
            oCount++;
        }
        if (oCount == 2 && blankCount == 1) {
            platform[blankX][blankY] = O_MOVE;
            matrix[blankX][blankY].setText("O");
            matrix[blankX][blankY].setEnabled(false);
            return true;
        }
        //check top right to bottom left diagonal
        oCount = 0;
        blankCount = 0;
        blankX = 0;
        blankY = 0;
        if (platform[2][0] == BLANK) {
            blankCount++;
            blankX = 2;
            blankY = 0;
        }
        if (platform[2][0] == player) {
            oCount++;
        }
        if (platform[1][1] == BLANK) {
            blankCount++;
            blankX = 1;
            blankY = 1;
        }
        if (platform[1][1] == player) {
            oCount++;
        }
        if (platform[0][2] == BLANK) {
            blankCount++;
            blankX = 0;
            blankY = 2;
        }
        if (platform[0][2] == player) {
            oCount++;
        }
        if (oCount == 2 && blankCount == 1) {
            platform[blankX][blankY] = O_MOVE;
            matrix[blankX][blankY].setText("O");
            matrix[blankX][blankY].setEnabled(false);
            return true;
        }
        return false;
    }

    public boolean checkWin(int player) { // checks to see if a player has won
        if (platform[0][0] == player && platform[0][1] == player && platform[0][2] == player) {
            return true;
        }
        if (platform[1][0] == player && platform[1][1] == player && platform[1][2] == player) {
            return true;
        }
        if (platform[2][0] == player && platform[2][1] == player && platform[2][2] == player) {
            return true;
        }
        if (platform[0][0] == player && platform[1][0] == player && platform[2][0] == player) {
            return true;
        }
        if (platform[0][1] == player && platform[1][1] == player && platform[2][1] == player) {
            return true;
        }
        if (platform[0][2] == player && platform[1][2] == player && platform[2][2] == player)
        {
            return true;
        }
        if (platform[0][0] == player && platform[1][1] == player && platform[2][2] == player) {
            return true;
        }
        if (platform[0][2] == player && platform[1][1] == player && platform[2][0] == player) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean checkTie() { //checks for ties
        for (int i = 0; i < platform.length; i++) {
            for (int j = 0; j < platform[0].length; j++) {
                if (platform[i][j] == BLANK) {
                    return false;
                }
            }
        }
        return true;
    }

    public void clearPlatform() { //clears platform
        for (int a = 0; a < platform.length; a++) {
            for (int b = 0; b < platform.length; b++) {
                platform[a][b] = BLANK;
                matrix[a][b].setText("");
                matrix[a][b].setEnabled(true);
            }
        }
    }
}